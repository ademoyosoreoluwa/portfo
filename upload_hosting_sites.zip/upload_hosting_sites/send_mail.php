<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form fields
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $subject = filter_var($_POST['subject'], FILTER_SANITIZE_STRING);
    $message = filter_var($_POST['message'], FILTER_SANITIZE_STRING);

    // Validate email
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format";
        exit;
    }

    // Define CSV file path
    $csvFile = 'database.csv';
    $csvData = [$email, $subject, $message];

    // Open CSV file for writing
    $fileHandle = fopen($csvFile, 'a');
    if ($fileHandle === false) {
        echo "Error opening the file.";
        exit;
    }

    // Write data to CSV file
    if (fputcsv($fileHandle, $csvData) === false) {
        echo "Error writing to the file.";
        exit;
    }

    // Close the file handle
    fclose($fileHandle);

    // Redirect to thank you page
    header("Location: thank_you.html");
    exit;
} else {
    echo "Invalid request.";
}
?>
